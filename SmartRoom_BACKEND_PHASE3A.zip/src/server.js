import http from 'node:http';
import { config } from './config.js';
import { table, add, update, remove, id, logEvent } from './store.js';
import { authHeader, body, noContent, route, send } from './http.js';
import { createToken, createUser, findUser, getUserFromToken, publicUser, verifyPassword } from './auth.js';

const collections = {
  rooms:'rooms', devices:'devices', functions:'functions', scenes:'scenes', automations:'automations', schedules:'schedules', sensors:'sensors'
};
const clean = (obj, forbidden=[]) => { const x={...obj}; for(const k of forbidden) delete x[k]; return x; };
function requireAuth(req,res){ const u=getUserFromToken(authHeader(req)); if(!u){send(res,401,{error:'unauthorized'});return null;} return u; }
function owned(name,userId){ return table(name).filter(x=>x.userId===userId); }
function ownedOne(name,userId,itemId){ return table(name).find(x=>x.id===itemId&&x.userId===userId); }

async function handler(req,res){
  if(req.method==='OPTIONS'){return noContent(res);}
  const {path,query}=route(req);
  if(req.method==='GET'&&path==='/api/health') return send(res,200,{ok:true,service:'smartroom-backend',time:new Date().toISOString(),version:'1.0.0'});

  if(req.method==='POST'&&path==='/api/auth/register'){
    const b=await body(req); if(!b||typeof b.email!=='string'||typeof b.password!=='string'||b.password.length<8) return send(res,400,{error:'email and password (8+ chars) required'});
    if(findUser(b.email)) return send(res,409,{error:'email already registered'});
    const u=createUser({email:b.email,name:b.name,password:b.password});
    // persist through store module by adding save-triggering no-op update
    const created=add('events',{id:id('evt'),timestamp:Date.now(),userId:u.id,type:'auth.registered'}); // event table write also persists
    return send(res,201,{user:publicUser(u),token:createToken(u)});
  }
  if(req.method==='POST'&&path==='/api/auth/login'){
    const b=await body(req),u=b?.email&&findUser(b.email);
    if(!u||!verifyPassword(String(b.password||''),u.passwordHash)) return send(res,401,{error:'invalid credentials'});
    return send(res,200,{user:publicUser(u),token:createToken(u)});
  }

  const user=requireAuth(req,res); if(!user) return;
  if(req.method==='GET'&&path==='/api/me') return send(res,200,{user:publicUser(user)});
  if(req.method==='GET'&&path==='/api/events') return send(res,200,{events:owned('events',user.id).slice(0,200)});

  // ESP32 nodes
  if(path==='/api/esp32/nodes'){
    if(req.method==='GET') return send(res,200,{items:owned('esp32Nodes',user.id)});
    if(req.method==='POST'){
      const b=await body(req); if(!b?.name) return send(res,400,{error:'name required'});
      const n=add('esp32Nodes',{id:id('esp'),userId:user.id,name:b.name,deviceId:b.deviceId||null,status:'offline',lastSeenAt:null,firmware:b.firmware||null,createdAt:Date.now()});
      logEvent({userId:user.id,type:'esp32.node.created',entityId:n.id}); return send(res,201,{item:n});
    }
  }
  const esp=/^\/api\/esp32\/nodes\/([^/]+)$/.exec(path);
  if(esp){ const item=ownedOne('esp32Nodes',user.id,esp[1]); if(!item)return send(res,404,{error:'not found'}); if(req.method==='PATCH'){const b=await body(req);return send(res,200,{item:update('esp32Nodes',item.id,clean(b,['id','userId','status','lastSeenAt']))});} if(req.method==='DELETE'){remove('esp32Nodes',item.id);return noContent(res);} }

  // Generic CRUD collections
  for(const [segment,name] of Object.entries(collections)){
    const base=`/api/${segment}`;
    if(path===base&&req.method==='GET') return send(res,200,{items:owned(name,user.id)});
    if(path===base&&req.method==='POST'){
      const b=await body(req); if(!b||typeof b!=='object')return send(res,400,{error:'JSON body required'});
      const item=add(name,{...clean(b,['id','userId','createdAt','updatedAt']),id:id(segment.slice(0,-1)||'item'),userId:user.id,createdAt:Date.now()});
      logEvent({userId:user.id,type:`${segment}.created`,entityId:item.id}); return send(res,201,{item});
    }
    const m=new RegExp(`^/api/${segment}/([^/]+)$`).exec(path);
    if(m){
      const item=ownedOne(name,user.id,m[1]); if(!item)return send(res,404,{error:'not found'});
      if(req.method==='GET')return send(res,200,{item});
      if(req.method==='PATCH'){const b=await body(req);const saved=update(name,item.id,clean(b,['id','userId','createdAt']));logEvent({userId:user.id,type:`${segment}.updated`,entityId:item.id});return send(res,200,{item:saved});}
      if(req.method==='DELETE'){remove(name,item.id);logEvent({userId:user.id,type:`${segment}.deleted`,entityId:item.id});return noContent(res);}
    }
  }

  // Device command endpoint — records intent only until hardware transport exists.
  const cmd=/^\/api\/devices\/([^/]+)\/commands$/.exec(path);
  if(cmd&&req.method==='POST'){
    const device=ownedOne('devices',user.id,cmd[1]); if(!device)return send(res,404,{error:'device not found'});
    const b=await body(req); if(!b?.capability)return send(res,400,{error:'capability required'});
    const command={id:id('cmd'),userId:user.id,deviceId:device.id,capability:b.capability,value:b.value??null,source:b.source||'app',status:'requested_waiting_for_hardware_acknowledgement',createdAt:Date.now()};
    logEvent({userId:user.id,type:'device.command.requested',entityId:device.id,payload:command});
    return send(res,202,{command,message:'Command accepted by backend; physical hardware acknowledgement is not available yet.'});
  }

  return send(res,404,{error:'route not found'});
}

const server=http.createServer((req,res)=>handler(req,res).catch(err=>{console.error(err);send(res,500,{error:'internal_server_error'});}));
server.listen(config.port,config.host,()=>console.log(`SmartRoom backend listening on http://${config.host}:${config.port}`));
