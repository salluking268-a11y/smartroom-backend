import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const dataDir = path.resolve(process.cwd(), 'data');
const file = path.join(dataDir, 'smartroom.json');
const empty = {
  users: [], rooms: [], devices: [], functions: [], scenes: [], automations: [], schedules: [], sensors: [], esp32Nodes: [], events: []
};
fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify(empty, null, 2));
let db = JSON.parse(fs.readFileSync(file, 'utf8'));
for (const k of Object.keys(empty)) if (!Array.isArray(db[k])) db[k] = [];

export const id = (prefix='id') => `${prefix}_${crypto.randomUUID()}`;
export function save(){
  const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, file);
}
export function table(name){ return db[name]; }
export function add(name, value){ db[name].push(value); save(); return value; }
export function update(name, idValue, patch){
  const i = db[name].findIndex(x => x.id === idValue);
  if(i < 0) return null;
  db[name][i] = {...db[name][i], ...patch, updatedAt: Date.now()}; save(); return db[name][i];
}
export function remove(name, idValue){
  const before = db[name].length;
  db[name] = db[name].filter(x => x.id !== idValue);
  if(db[name].length !== before) save();
  return before !== db[name].length;
}
export function logEvent(event){
  db.events.unshift({id:id('evt'), timestamp:Date.now(), ...event});
  if(db.events.length > 2000) db.events.length = 2000;
  save();
}
