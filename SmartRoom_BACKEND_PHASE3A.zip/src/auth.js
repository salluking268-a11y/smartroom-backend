import crypto from 'node:crypto';
import { config } from './config.js';
import { table, id } from './store.js';

const b64 = b => Buffer.from(b).toString('base64url');
const unb64 = b => Buffer.from(b, 'base64url');
const sign = input => crypto.createHmac('sha256', config.jwtSecret).update(input).digest('base64url');

export function hashPassword(password){
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}
export function verifyPassword(password, stored){
  const [salt, hex] = String(stored).split(':');
  if(!salt || !hex) return false;
  const got = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(got,'hex'), Buffer.from(hex,'hex'));
}
export function createToken(user){
  const header = b64(JSON.stringify({alg:'HS256',typ:'JWT'}));
  const payload = b64(JSON.stringify({sub:user.id,email:user.email,iat:Math.floor(Date.now()/1000),exp:Math.floor(Date.now()/1000)+60*60*24*30}));
  return `${header}.${payload}.${sign(`${header}.${payload}`)}`;
}
export function getUserFromToken(token){
  const parts = String(token||'').split('.');
  if(parts.length !== 3) return null;
  const [h,p,s] = parts;
  if(sign(`${h}.${p}`) !== s) return null;
  let payload;
  try { payload = JSON.parse(unb64(p)); } catch { return null; }
  if(payload.exp && payload.exp < Math.floor(Date.now()/1000)) return null;
  return table('users').find(u=>u.id===payload.sub) || null;
}
export function publicUser(u){ return {id:u.id,email:u.email,name:u.name,createdAt:u.createdAt}; }
export function findUser(email){ return table('users').find(u=>u.email.toLowerCase()===email.toLowerCase()); }
export function createUser({email,name,password}){
  const user={id:id('usr'),email:email.toLowerCase(),name:name||'SmartRoom User',passwordHash:hashPassword(password),createdAt:Date.now()};
  table('users').push(user); return user;
}
