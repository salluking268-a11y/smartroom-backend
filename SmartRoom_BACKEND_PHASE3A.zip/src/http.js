import { URL } from 'node:url';
export function send(res,status,data){
  const body=JSON.stringify(data);
  res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Allow-Methods':'GET,POST,PATCH,DELETE,OPTIONS'});
  res.end(body);
}
export function noContent(res){ res.writeHead(204,{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Allow-Methods':'GET,POST,PATCH,DELETE,OPTIONS'}); res.end(); }
export async function body(req){
  let raw=''; for await(const chunk of req) raw+=chunk; if(!raw) return {};
  try{return JSON.parse(raw)}catch{return null;}
}
export function route(req){ const u=new URL(req.url,`http://${req.headers.host||'localhost'}`); return {path:u.pathname,query:u.searchParams}; }
export function authHeader(req){ const m=String(req.headers.authorization||'').match(/^Bearer\s+(.+)$/i); return m?.[1]||null; }
